
$(document).ready(function(){



  var APP_URL = "https://postdelay.shopifyapplications.com";
  //       var APP_URL = "http://127.0.0.1:8000";

  var url = window.location.href;

  $('body').on('click','.tooltip',function(){
    if( $(this).find('.link-to-open').length > 0 ){
      window.open( $(this).find('.link-to-open').attr('data-href'), '_blank');   
    }
  });


  $('body').on('click', '.accordin .Form-content-name', function(){
    $(this).toggleClass('active');
    $(this).next().toggle();
  });

  //   console.log($('body').hasClass('product-thumbnail__image'))

  //   if($('body').hasClass('product-thumbnail__image')){
  //   $('.product-thumbnail__image').attr('src','https://cdn.shopify.com/s/files/1/0120/3106/6193/files/Screenshot_36.png');
  //   }

  if(url.indexOf('#recover') > -1){
    $('div#CustomerLoginForm').hide();
    $('#RecoverPasswordForm').removeClass('hide');
  }

  if(url.indexOf('account/invalid_token') > -1){
    window.location.href="/account/register";
  }

  if(url.indexOf('/pages/account_delete') > -1){
    if(url.indexOf('#/customer/id/') > -1){
      var idd = url.split('#/customer/id/')[1];
      deleteAccount(APP_URL,idd);
    }else{
      window.location.href = '/';
    }
  }
  $(".FAQ-Head").click(function () {
    $('.FAQ-contaner').removeClass('active');
    $(this).parent().toggleClass( "active"); 
  });

  //   $("#Phone").inputmask({"mask": "9999999999"});

  $('body').on('submit','#modify_ship_out_date_form',function(e){
    $('.page-width-2').addClass('loading');
    e.preventDefault();
    var $form = $(this);

    $.ajax({
      type:'post',
      url: APP_URL+'/update/order/modify-date/ajax',
      data:$form.serialize(),
      success:function(data){
        if(data.message === 'success'){
          location.reload();
        }
        else{
          $('.page-width-2').removeClass('loading');
          alert('cant modify the date!');
        }

      }
    });

  });


  $('#customer_login').submit(function(e){

    e.preventDefault();
    var $form = $(this);

    $.ajax({
      type:'GET',
      url: APP_URL+'/check/customer/status',
      data:$form.serialize(),
      success:function(data){
        if(data.status === 'deleting'){
          $('#customer_status_div').empty();
          $('#customer_status_div').append('Your account is in delete mode, For Reactivation <a id="reactivate_account"> Click Here </a>');
          $('#customer_status_div').addClass('error');
          $('#customer_status_div').show();
        }

        else if(data.status === 'disabled'){
          $('#customer_status_div').empty();
          $('#customer_status_div').append('Your account is disabled by Administration, For Reactivation <a id="reactivate_account"> Click Here </a>');
          $('#customer_status_div').addClass('error');
          $('#customer_status_div').show();
        }
        else if(data.status === 'inactive'){
          $('#customer_status_div').empty();
          $('#customer_status_div').append('This account has been deleted. Please send a message to sales@postdelay.com to have the account reinstated');
          $('#customer_status_div').addClass('error');
          $('#customer_status_div').show();
        }

        else{
          $form.submit();
        }
      }
    });

  });


  $('body').on('click','#reactivate_account',function(){
    var $form = $('#customer_login');

    $.ajax({
      type:'GET',
      url: APP_URL+'/update/customer/status',
      data:$form.serialize(),
      success:function(data){
        if(data.status === 'enabled'){
          $('#customer_status_div').empty();
          $('#customer_status_div').append('Your account reactivated');
          $('#customer_status_div').removeClass('error');
          $('#customer_status_div').addClass('success');
          $('#customer_status_div').show();
        }
      }
    });

  });

  //   $('#create_account_button').click(function(){
  //     if($.trim($('#Phone').val()) == ''){
  //       $('.status_wrapper').addClass('error');
  //       $('.status_wrapper').removeClass('success');
  //       $('.status_wrapper').show();
  //       $('.status_wrapper').append('Phone Required');
  //     }
  //   });


  $('#create_customer_account').submit(function(e){

    $('.Form-wraper').addClass('loading');
    e.preventDefault();
    var $form = $(this);
    if($('.country_select').val() === '---'){
      $('.Form-wraper').removeClass('loading');
      $('#country-status').html("Please Select Country !");
      $('#country-status').focus();
    }
    else if($('input[name=address1]').val() === ''){
      $('.Form-wraper').removeClass('loading');
      $('#country-status').html("Street address invalid !");
      var scrollPos =  $("#country-status").offset().top;
      $(window).scrollTop(scrollPos);
    }

    else{
      $.ajax({
        type:$form.attr('method'),
        url: APP_URL+$form.attr('action'),
        data:$form.serialize(),
        success:function(data){
          var obj = JSON.parse(data);
          $('.Form-wraper').removeClass('loading');
          if(obj.status != 'success'){
            $('.status_wrapper').addClass('error');
            $('.status_wrapper').removeClass('success');
            $('.status_wrapper').show();
            $('.status_wrapper').html(parseHtmlEnteties(obj.msg));
          }else{
            $('#register_form').css('display','none');
            $('#account_activation_div').css('display','block');
            $('#send_activation_link').attr('data-customer-id',obj.customer_id);
          }
          //           if(data.password){
          //             $('#password-strength-status').html(data.password[0]);
          //           }
          //           if(data.msg){

          //             $('#register_form').css('display','none');
          //             $('#account_activation_div').css('display','block');
          //             $('#send_activation_link').attr('data-customer-id',data.customer_id);
          //           }
          //           if(data.email){
          //             $('#email-status').html(data.email[0]);
          //           }
        }
      });
    }


  });


  $('body').on('click', '#send_activation_link',  function(){
    $('.Form-wraper').addClass('loading');
    $.ajax({
      type:'GET',
      url: APP_URL+'/send-activation-link',
      data:{
        customer_id : $(this).data('customer-id'),
        shop : $(this).data('shop'),
      },
      success:function(data){
        $('#register_form').css('display','none');
        $('.Form-wraper').removeClass('loading');
        $('#account_activation_div').css('display','none');
        $('#account_activation_link_sent_div').css('display','block');
      }
    });
  });


  $('#RecoverPassword').click(function(){

    $('#CustomerLoginForm').css('display','none');
    $('#RecoverPasswordForm').removeClass('hide');

  });


  $('#HideRecoverPasswordLink').click(function(){

    $('#CustomerLoginForm').css('display','block');
    $('#RecoverPasswordForm').addClass('hide');

  });


  //   $('#sendRecoverPasswordLink').click(function(){

  //     $('#CustomerLoginForm').css('display','none');
  //     $('#RecoverPasswordForm').addClass('hide');
  //     $('#password_reset_link_sent_div').css('display','block');
  //     $('#ResetSuccess').removeClass('hide')

  //   });


  $('#BackToLogin').click(function(){

    $('#CustomerLoginForm').css('display','block');
    $('#RecoverPasswordForm').addClass('hide');
    $('#password_reset_link_sent_div').css('display','none');

  });


  $('body').on('change','.AddressCountryNew', function(){
    //     changeCountry($(this));

  });

  $('.new-addresses-page').ready(function(){

    if ($('body .new-addresses-page').length > 0)
    {
      change_countries();
    }
  });

  $('body').on('change','#Address-Type',function(){
    change_countries();
  });

  function change_countries(){

    if($('#Address-Type').val() === 'Billing' || $('#Address-Type').val() === 'Sender'){
      var countries = $('#country_list').html();
      $('select[name=country]').empty();   
      $('select[name=country]').append(countries);
    }
    else{
      var countries = $('#recipient_country_list').html();
      $('select[name=country]').empty();
      $('select[name=country]').append(countries);
    }
  }


  $('#create_customer_address_form').submit(function(e){
    $('.Form-wraper').addClass('loading');
    e.preventDefault();
    var $form = $(this);
    if($('#AddressCountryNew').val() === '---'){
      $('.Form-wraper').removeClass('loading');
      $('#country-status').html("Please Select Country !");
    }
    if($('input[name=address1]').val() === ''){
      $('.Form-wraper').removeClass('loading');
      $('#country-status').html("street address invalid !");
      var scrollPos =  $("#country-status").offset().top;
      $(window).scrollTop(scrollPos);
    }
    else{
      $.ajax({
        type:$form.attr('method'),
        url: APP_URL+$form.attr('action'),
        data:$form.serialize(),
        success:function(data){
          $('.Form-wraper').removeClass('loading');
          $('#address_creation_div').css('display','none');
          $('#address_created_div').css('display','block');
        },
        error: function(){
          $('.Form-wraper').removeClass('loading');
          status_message($form, 'This address already exists, please enter a unique address.', 'error');
        }
      });
    }

  });


  $('#customer_detail_page').ready(function(){

    if ($('body .customer_detail_page').length > 0)
    {
      $('.page-width-1').addClass('loading');
      dataload();
      multipleAddress();
    }

  });


  $('body').on('submit','#update_customer_details_form',function(e){
    $('.page-width-1').addClass('loading');
    e.preventDefault();
    var $form = $(this);

    $.ajax({
      type:$form.attr('method'),
      url: APP_URL+$form.attr('action'),
      data:$form.serialize(),
      success:function(data){

        $('.page-width-1').removeClass('loading');

        if(data.email){
          $('#CustomerUpdateSuccess').removeClass('hide');
          $('#CustomerUpdateSuccess').removeClass('form-message--success');
          $('#CustomerUpdateSuccess').addClass('form-message--danger');
          $('#CustomerUpdateSuccess').html(data.email[0]);
        }
        else{

          $('#CustomerUpdateSuccess').addClass('form-message--success');
          $('#CustomerUpdateSuccess').removeClass('form-message--danger');
          $('#CustomerUpdateSuccess').removeClass('hide');
          $('#CustomerUpdateSuccess').html(data.msg);
        }

      }
    });


  });

  $('body').on('click','#billing_address_button',function(e){

    if($('#billing_address').val() !== null){
      $('.page-width-1').addClass('loading');
      $.ajax({

        type:"GET",
        url: APP_URL+'/customer/address/default',
        data: {

          address_id: $('#billing_address').val(),

        },
        success:function(data){

          $('.page-width-1').removeClass('loading');
          $('.Form-content-detail_custom').empty();
          dataload();

        }
      });
    }

  });

  $('body').on('click','#sender_address_button',function(e){

    if($('#sender_address').val() !== null){
      $('.page-width-1').addClass('loading');
      $.ajax({
        type:"GET",
        url: APP_URL+'/customer/address/default',
        data: {
          address_id: $('#sender_address').val(),
        },
        success:function(data){
          $('.page-width-1').removeClass('loading');
          $('.Form-content-detail_custom').empty();
          dataload();
        }
      });
    }

  });

  $('body').on('click','#recipients_address_button',function(e){

    if($('#recipients_address').val() !== null){
      $('.page-width-1').addClass('loading');
      $.ajax({

        type:"GET",
        url: APP_URL+'/customer/address/default',
        data: {
          address_id: $('#recipients_address').val(),

        },
        success:function(data){

          $('.page-width-1').removeClass('loading');
          $('.Form-content-detail_custom').empty();
          dataload();

        }
      });
    }

  });

  $('body').on('click','#recipients_address_remove_button',function(e){
    var confirmation = confirm("Are you sure want to remove this address?");

    if(confirmation){
      if($('#recipients_address').val() !== null){
        $('.page-width-1').addClass('loading');
        $.ajax({

          type:"GET",
          url: APP_URL+'/customer/addresses/delete-address',
          data: {

            address_id: $('#recipients_address').val(),

          },
          success:function(data){

            $('.Form-content-detail_custom').empty();
            dataload();

          },
          error:function(jqXHR, exception){
            $('.page-width-1').removeClass('loading');
            $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('hide');
            $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('form-message--success');
            $('.customer_detail_page').find('#RecoverPasswordStatus').addClass('form-message--danger');
            $('.customer_detail_page').find('#RecoverPasswordStatus').html('Cannot delete default address');
          }
        });
      }
    }
  });

  $('body').on('click','#billing_address_remove_button',function(e){

    var confirmation = confirm("Are you sure you want to remove this address?");

    if(confirmation){
      if($('#billing_address').val() !== null){

        $('.page-width-1').addClass('loading');
        $.ajax({

          type:"GET",
          url: APP_URL+'/customer/addresses/delete-address',
          data: {

            address_id: $('#billing_address').val(),

          },
          success:function(data){
            $('.Form-content-detail_custom').empty();
            dataload();

          },
          error:function(jqXHR, exception){
            $('.page-width-1').removeClass('loading');
            $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('hide');
            $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('form-message--success');
            $('.customer_detail_page').find('#RecoverPasswordStatus').addClass('form-message--danger');
            $('.customer_detail_page').find('#RecoverPasswordStatus').html('Cannot delete default address');
          }
        });
      }
    }
  });

  $('body').on('click','#sender_address_remove_button',function(e){

    var confirmation = confirm("Are you sure you want to remove this address?");

    if(confirmation){
      if($('#sender_address').val() !== null){

        $('.page-width-1').addClass('loading');
        $.ajax({

          type:"GET",
          url: APP_URL+'/customer/addresses/delete-address',
          data: {

            address_id: $('#sender_address').val(),

          },
          success:function(data){

            $('.Form-content-detail_custom').empty();
            dataload();

          },
          error:function(jqXHR, exception){
            $('.page-width-1').removeClass('loading');
            $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('hide');
            $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('form-message--success');
            $('.customer_detail_page').find('#RecoverPasswordStatus').addClass('form-message--danger');
            $('.customer_detail_page').find('#RecoverPasswordStatus').html('Cannot delete default address');
          }
        });
      }
    }


  });

  function dataload(){
    $.ajax({

      type:"GET",
      url: APP_URL+'/customer/get/details?customer_id='+$('#customer_detail_page').attr('data-customer-id')+'&&shop='+  $('#customer_detail_page').attr('data-shop'),   
      success:function(data){

        $('.page-width-1').removeClass('loading');
        $('.Form-content-detail_custom').append(data.html);
        initAutocomplete();
        multipleAddress();
      }
    });
  }

  $('#new-order').ready(function(){

    if ($('body .new-order').length > 0)
    {
      $.ajax({

        type:"GET",
        url: APP_URL+'/customer/get/new_order?customer_id='+$('#new-order').attr('data-customer-id')+'&&shop='+  $('#new-order').attr('data-shop'),   
        success:function(data){
          $('.page-width-2').empty();
          $('.page-width-2').removeClass('loading');
          $('.page-width-2').append(data.html);
          new_order_post_type($('#TypeSelect'));
          //           initAutocomplete();
        }
      });

    }

  });

  //   $('body').on('change','select[name=receipent_country]',function(){
  //     if($(this).val() === 'United States'){
  // //       if($("#TypeSelect option[value='POSTCARD']").length < 0){
  //          $('.new-order').find('#TypeSelect option[value=POSTCARD]').show();
  // //         $('.new-order').find('#TypeSelect').prepend('<option value="POSTCARD">Postcard</option>');
  // //       }
  //       $('.new-order').find('#TypeSelect').val('POSTCARD').change();
  //       new_order_post_type($('#TypeSelect'));
  //     }
  //     else{
  //       $('.new-order').find('#TypeSelect option[value=POSTCARD]').hide();
  //       $('.new-order').find('#TypeSelect').val('LETTER').change();
  //       new_order_post_type($('#TypeSelect'));
  //     }

  //   });


  $('body').on('change','#receipent_address_select',function(){
    var sender_address = $('.page-width-2').find('#sender_address_select').val();
    var billing_address = $('.page-width-2').find('#billing_address_select').val();
    form_data_load(sender_address,billing_address,$(this).val());

  });

  $('body').on('change','#sender_address_select',function(){
    var billing_address = $('.page-width-2').find('#billing_address_select').val();
    var receipt_address = $('.page-width-2').find('#receipent_address_select').val();
    form_data_load($(this).val(),billing_address,receipt_address);

  });

  $('body').on('change','#billing_address_select',function(){
    var sender_address = $('.page-width-2').find('#sender_address_select').val();
    var receipt_address = $('.page-width-2').find('#receipent_address_select').val();
    form_data_load(sender_address,$(this).val(),receipt_address);

  });

  function form_data_load(sender_address,billing_address,receipt_address){
    $.ajax({
      type:"GET",
      url: APP_URL+'/customer/put/addresses',
      data:{
        customer_id:$('#new-order').attr('data-customer-id'),
        shop:$('#new-order').attr('data-shop'),
        sender_address:sender_address,
        billing_address:billing_address,
        recipient_address:receipt_address

      },
      success:function(data){
        $('.page-width-2').empty();
        $('.page-width-2').append(data.html);

        multipleAddress();
        new_order_post_type($('#TypeSelect'));
        //         initAutocomplete();

      }
    });
  }

  $('body').on('submit','#get_shipping_rates',function(e){
    $('#modification').val('0');
    $('.page-width-2').addClass('loading');
    e.preventDefault();
    var form = $(this);
    $.ajax({
      type:form.attr('method'),
      url: APP_URL+form.attr('action'),
      data:form.serialize(),
      success:function(data){
        AddToCartWithShipping(data);
      }
    });

  });


  $('body').on('submit','#place_order_form',function(e){
    if($('#modification').val() === '1'){
      alert('You have modify the details, pls refresh quote');
    }
    else{
      $('.page-width-2').addClass('loading');
      e.preventDefault();

      var form = $(this);
      $.ajax({
        type:form.attr('method'),
        url: APP_URL+form.attr('action'),
        data:form.serialize(),
        success:function(data){
          $('.page-width-2').removeClass('loading');

          window.location.href = data.invoiceURL;
        }
      });
    }

  });


  $('existing-orders').ready(function(){

    if ($('body .existing-orders').length > 0)
    {
      $.ajax({

        type:"GET",
        url: APP_URL+'/orders?customer_id='+$('#existing-orders').attr('data-customer-id')+'&&shop='+  $('#existing-orders').attr('data-shop'),   
        success:function(data){


          $('.Form-contaner').append(data.html);

        }
      });

    }

  });

  $('order').ready(function(){
    if ($('body .order').length > 0)
    {
      $.ajax({
        type:"GET",
        url: APP_URL+'/getdata?customer_id='+$('#order').attr('data-customer-id')+'&&shop='+$('#order').attr('data-shop')+'&&customer_url='+$('#order').attr('data-order-url'),   
        success:function(data){

          $('.sender_detail_form').empty();
          $('.sender_detail_form').append(data.sender_form_html);

          $('.order_status_div').empty();
          $('.order_status_div').append(data.order_status);

          $('.shipment_detail_div').empty();
          $('.shipment_detail_div').append(data.shipment_details);

          $('.billing_email').empty();
          $('.billing_email').append(data.billing_email);

          $('.shipping_email').empty();
          $('.shipping_email').append(data.recepient_email);

          $('.additional_fee_div').empty();
          $('.additional_fee_div').append(data.additional_fee);

          $('.key_date_div').empty();
          $('.key_date_div').append(data.keydate);

          $('.shipment_to_postdelay_div').empty();
          $('.shipment_to_postdelay_div').append(data.shipment_to_postdelay);

          $('.response_div').append(data.response_form);
          if($('body').find('#cancellation').attr('data-show') === '0'){
            $('#cancel-order').hide();
            $('#cancel-order').next().next().hide();
          }
          if(data.response_form_status === 'yes'){
            $('.response_div').show();

          }
          else{
            $('.response_div').hide();

          }

        }
      });

    }

  });

  $('#recipient').click(function(e){
    $(this).removeClass('Same-button');
    $(this).addClass('Active-button');

    $('#sender').addClass('Same-button');
    $('#sender').removeClass('Active-button');

    $('#billing').addClass('Same-button');
    $('#billing').removeClass('Active-button');

    $.ajax({
      type:"GET",
      url: APP_URL+'/get/addresses?type='+$(this).attr('data-type')+'&&customer_id='+$(this).attr('data-id'),
      success:function(data){
        if(data.addresses.length >=1 ){
          $('#Address').empty();
          $('#Address').append(new Option('---','---'));
          $.each(data.addresses,function (key,value) {
            if(value.address2 === null){
              $('#Address').append(new Option(value.first_name+' '+value.last_name+', '+value.address1+', '+value.city+', ' +value.state+', '+value.country+', '+value.postcode, value.id));

            }
            else{
              $('#Address').append(new Option(value.first_name+' '+value.last_name+', '+value.address1+', '+value.address2+', '+value.city+', ' +value.state+' '+value.country+', '+value.postcode, value.id));

            }
          });
          address_status(true);
        } else  {
          address_status(false);
        }

      },

    });

  });

  $('#sender').click(function(e){

    $(this).removeClass('Same-button');
    $(this).addClass('Active-button');

    $('#recipient').addClass('Same-button');
    $('#recipient').removeClass('Active-button');

    $('#billing').addClass('Same-button');
    $('#billing').removeClass('Active-button');

    $.ajax({

      type:"GET",
      url: APP_URL+'/get/addresses?type='+$(this).attr('data-type')+'&&customer_id='+$(this).attr('data-id'),
      success:function(data){
        if(data.addresses.length >=1 ){
          $('#Address').empty();
          $('#Address').append(new Option('---','---'));
          $.each(data.addresses,function (key,value) {
            if(value.address2 === null){
              $('#Address').append(new Option(value.first_name+' '+value.last_name+', '+value.address1+', '+value.city+', ' +value.state+', '+value.country+', '+value.postcode, value.id));

            }
            else{
              $('#Address').append(new Option(value.first_name+' '+value.last_name+', '+value.address1+', '+value.address2+', '+value.city+', ' +value.state+' '+value.country+', '+value.postcode, value.id));

            }
          });
          address_status(true);        
        }else{
          address_status(false);
        }

      },

    });



  });

  $('#billing').click(function(e){

    $(this).removeClass('Same-button');
    $(this).addClass('Active-button');

    $('#sender').addClass('Same-button');
    $('#sender').removeClass('Active-button');

    $('#recipient').addClass('Same-button');
    $('#recipient').removeClass('Active-button');

    $.ajax({

      type:"GET",
      url: APP_URL+'/get/addresses?type='+$(this).attr('data-type')+'&&customer_id='+$(this).attr('data-id'),
      success:function(data){
        if(data.addresses.length >=1 ){
          $('#Address').empty();
          $('#Address').append(new Option('---','---'));
          $.each(data.addresses,function (key,value) {
            if(value.address2 === null){
              $('#Address').append(new Option(value.first_name+' '+value.last_name+', '+value.address1+', '+value.city+', ' +value.state+', '+value.country+', '+value.postcode, value.id));

            }
            else{
              $('#Address').append(new Option(value.first_name+' '+value.last_name+', '+value.address1+', '+value.address2+', '+value.city+', ' +value.state+' '+value.country+', '+value.postcode, value.id));

            }

          });
          address_status(true);
        } else {
          address_status(false);
        }

      },

    });

  });

  $('#Address').change(function(e){
    $.ajax({ 
      type:"GET",
      url: APP_URL+'/get/addresses/type?address='+$(this).val(),
      success:function(data){
        $('.Form-content-detail').html(data.html);
        $('.Form-content-detail').show();
        initAutocomplete();
        multipleAddress();
      },

    });

  });

  $('body').on('submit','#address_update_form',function(e){
    e.preventDefault();
    $('.Form-content-detail').addClass('loading');
    var $form = $(this);
    $.ajax({
      type:$form.attr('method'),
      url: APP_URL+$form.attr('action'),
      data:$form.serialize(),
      success:function(data){
        $('.Form-content-detail').removeClass('loading');
        $('.Form-content-detail').empty();
        $('.Form-content-detail').append(data.html);
        multipleAddress();
      }
    });

  });

  $('body').on('click','#remove_address_button',function(e){

    var confirmation = confirm("Are you sure you want to remove this address?");

    var addresss =  $(this).attr('data-address-id');
    if(confirmation){
      $('.Form-content-detail').addClass('loading');
      $.ajax({

        type:"GET",
        //         url: APP_URL+'/customer/address/delete',
        url: APP_URL+'/customer/addresses/delete-address',
        data: {

          address_id: $(this).attr('data-address-id'),

        },
        success:function(data){
          $('.Form-content-detail').removeClass('loading');
          $('.Form-content-detail').empty();
          $("#Address option[value="+addresss+"]").remove();
        },
        error:function(jqXHR, exception){
          $('.page-width-1').removeClass('loading');
          $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('hide');
          $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('form-message--success');
          $('.customer_detail_page').find('#RecoverPasswordStatus').addClass('form-message--danger');
          $('.customer_detail_page').find('#RecoverPasswordStatus').html('Cannot delete default address');
        }
      });
    }




  });

  $('body').on('change','#request_billing_address_select',function(e){

    let searchParams = new URLSearchParams(window.location.search);
    let response = searchParams.get('response');
    $.ajax({ 
      type:"GET",
      url: APP_URL+'/request-form/billing-address?address='+$(this).val()+"&&response="+response,
      success:function(data){
        $('.Form-content-detail').empty();
        $('.Form-content-detail').append(data.html);
        multipleAddress();
      },

    });
  });

  $('.request-form').ready(function(){

    if ($('body .request-form').length > 0)
    {

      let searchParams = new URLSearchParams(window.location.search);
      let param = searchParams.get('order-id');
      let response = searchParams.get('response');
      let page_view = searchParams.get('view');

      console.log(response);

      if(response === '17'){
        $('#additional_feee_message').empty();
        $('#additional_feee_message').append('<p class="Custom-message-desp ">Additional funds are required to send your shipment back to you</p>');
        $('#additional-request-form input[type=submit]').val('GET QUOTE');
      }
      else if(response === '20'){
        $('#additional_feee_message').empty();
        $('#additional_feee_message').append('<p class="Custom-message-desp ">Additional funds are required to retry your undelivered shipment to destination </p>');
        $('#additional-request-form input[type=submit]').val('GET QUOTE');
      }
      else if(response === '21'){
        $('#additional_feee_message').empty();
        $('#additional_feee_message').append('<p class="Custom-message-desp ">Additional funds are required to send your undelivered shipment back to you </p>');
        $('#additional-request-form input[type=submit]').val('GET QUOTE');
      }
      else if(response === '9') {
        $('#additional_feee_message').empty();
        $('#additional_feee_message').append('<p class="Custom-message-desp ">Additional funds are required to send your cancelled shipment back to you </p>');
        $('#additional-request-form input[type=submit]').val('GET QUOTE');
      }

      $('#associate-order').val(param);

      $.ajax({

        type:"GET",
        url: APP_URL+'/request-form?customer_id='+$('#request-form').attr('data-customer-id')+'&&shop='+  $('#request-form').attr('data-shop')+'&&order='+param+'&&type='+page_view+'&&response='+response,   
        success:function(data){
          $('#select_billing').empty();
          $('#select_billing').append(data.html);
          $('.Form-content-detail').empty();
          $('.Form-content-detail').append(data.fill_address);

          multipleAddress();
        }
      });

    }

  });


  $('#additional-request-form').submit(function(e){
    var $form = $(this);
    $('body').find('#tempo').empty();
    $('body').find('#tempo').hide();
    e.preventDefault();
    if($(this).find('#additional_payment_section').length > 0){
      console.log('ready-to-go');
      if($(this).find('#additional_payment_section').attr('data-quote') === 'no'){
        $.ajax({
          type:'GET',
          url: APP_URL+'/get/re-calculate-form',
          data:$form.serialize(),
          success:function(data){
            $('.request-form').find('#re-calculate-form').remove();
            $('.request-form').append(data.html);
            var $form =   $('.request-form').find('#re-calculate-form');
            $.ajax({
              type:$form.attr('method'),
              url: $form.attr('action'),
              data:$form.serialize(),
              success:function(s){
                if(s.error === null){
                  $('body').find('#shipping_method_select').empty();    
                  $('body').find('#shipping_method_select').prop('required', true);
                  $('body').find('#shipping_method_select').append('<option value="">--Select--</option>')
                  console.log(s.services.length);
                  if(s.services.length >= 1){
                    $.each(s.services, function(i, item) {
                      console.log(item);
                      if(s.status === 'domestic'){

                        set_rates(item.Rate,item.MailService);
                      }
                      else{

                        set_rates(item.Postage,item.SvcDescription+' '+item.SvcCommitments);
                      }
                    });

                  }
                  else if(s.services.MailService !== null && s.status === 'domestic') {
                    set_rates(s.services.Rate,s.services.MailService);

                  }
                  else if(s.services.MailService !== null && s.status === 'international'){
                    set_rates(s.services.Postage,s.services.SvcDescription+' '+s.services.SvcCommitments);
                  }
                  else{

                  }
                  $('body').find('#shipping_method_select').find('option').each(function(){
                    $(this).val($(this).text());
                  });

                  $('body').find('#additional_payment_section').show();
                  $('body').find('#additional_payment_section').attr('data-quote','yes');
                  $('#additional-request-form input[type=submit]').val('Complete Payment');
                }
              },

            });
          }
        });

      }
      else{
        if($('body').find('select[name=shipping_method]').val() !== '--Select--'){
          $.ajax({
            type:$form.attr('method'),
            url: APP_URL+$form.attr('action'),
            data:$form.serialize(),
            success:function(data){
              window.location.href = data.invoiceURL;
            }
          });
        }
        else{
          $('body').find('#tempo').text('Please Select Shipping Method');
          $('body').find('#tempo').css('color','red');
          $('body').find('#tempo').css('font-size','12px');
          $('body').find('#tempo').show();
        }

      }

    }
    else{ 
      $.ajax({
        type:$form.attr('method'),
        url: APP_URL+$form.attr('action'),
        data:$form.serialize(),
        success:function(data){
          window.location.href = data.invoiceURL;
        }
      });
    }

  });

  $('body').on('change','#additional-request-form input',function(){
    if($('body').find('#additional_payment_section').length > 0){
      $('body').find('#additional_payment_section').hide();
      $('body').find('#additional_payment_section').attr('data-quote','no');
      $('#additional-request-form input[type=submit]').val('GET QUOTE');
    }
  });



  $('#shipment-to-postdelay-form').submit(function(e){

    e.preventDefault();
    var $form = $(this);
    $.ajax({
      type:$form.attr('method'),
      url: APP_URL+$form.attr('action'),
      data:$form.serialize(),
      success:function(data){
        window.location.reload();
      }
    });
  });



  function multipleAddress(){

    setTimeout(function() {
      $('.AddressCountryNew').each(function(){
        var country = $(this).attr('data-country-select');
        var province = $(this).attr('data-province-select');
        console.log(country, province);
        if(country){
          $(this).val(country).change();
          //           changeCountry($(this));
        }
        if(province){
          $(this).parents('.custom_fields_half').siblings().find('.AddressProvinceNew2').val(province).change();
        }
      });
    }, 500);
  }

  function changeCountry($this){
    var $parent = $this.parent().parent().parent();
    $parent.find('.AddressProvinceNew').empty();
    var data_provinces = $('option:selected', $this).attr('data-provinces');
    var provinces = JSON.parse(data_provinces);
    var length = provinces.length;
    if(length === 0){
      $parent.find('#city_div').addClass('custom_fields_half');
      $parent.find('#city_div').removeClass('custom_fields_third');
      $parent.find('#postal_div').addClass('custom_fields_half');
      $parent.find('#postal_div').removeClass('custom_fields_third');
      $parent.find('#province_div').addClass('hide');
    }
    else{
      $parent.find('#city_div').removeClass('custom_fields_half');
      $parent.find('#city_div').addClass('custom_fields_third');
      $parent.find('#postal_div').removeClass('custom_fields_half');
      $parent.find('#postal_div').addClass('custom_fields_third');
      $parent.find('#province_div').removeClass('custom_fields_half');
      $parent.find('#province_div').addClass('custom_fields_third');
      $parent.find('#province_div').removeClass('hide');

      $parent.find('.AddressProvinceNew').empty();
      for(var i=0; i<length; i++){
        $parent.find('.AddressProvinceNew').append(new Option(provinces[i][0],provinces[i][1]));
      }
    }
    return true;
  }



  $('body').on('click','#change-password',function(e){

    e.preventDefault();
    var $form =  $('#RecoverPasswordForm').find('form');
    $.ajax({
      type:$form.attr('method'),
      url: 'https://postdelay.myshopify.com'+$form.attr('action'),
      data:$form.serialize(),
      success:function(data){

        $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('hide');
        $('.customer_detail_page').find('#RecoverPasswordStatus').addClass('form-message--success');
        $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('form-message--danger');
        $('.customer_detail_page').find('#RecoverPasswordStatus').html('Password-Reset link has been send to your email-address');


      },
      error:function(jqXHR, exception){


        $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('hide');
        $('.customer_detail_page').find('#RecoverPasswordStatus').removeClass('form-message--success');
        $('.customer_detail_page').find('#RecoverPasswordStatus').addClass('form-message--danger');
        $('.customer_detail_page').find('#RecoverPasswordStatus').html('Too many password reset attempts. Retry in 10 minutes');


      }

    });

  });

  function set_threshold_on_ship_out_date(type){
    if(type.val() === 'POSTCARD' || type.val() === 'ENVELOPE' || type.val() === 'LETTER' ){

      var newdate = new Date();
      newdate.setDate(newdate.getDate() + parseInt($('input[name=ship_out_date]').attr('data-letters'))); // minus the date
      var days = newdate.getDate();
      if (days < 10) {
        days = "0" + days;
      }
      $('input[name=ship_out_date]').attr('max',newdate.getFullYear()+'-'+("0" + (newdate.getMonth() + 1)).slice(-2)+'-'+days);


    }
    else{
      var newdate = new Date();
      newdate.setDate(newdate.getDate() + parseInt($('input[name=ship_out_date]').attr('data-packages'))); // minus the date
      var days = newdate.getDate();
      if (days < 10) {
        days = "0" + days;
      }
      $('input[name=ship_out_date]').attr('max',newdate.getFullYear()+'-'+("0" + (newdate.getMonth() + 1)).slice(-2)+'-'+days);
    }
  }


  $('body').on('change','#TypeSelect',function(){
    set_threshold_on_ship_out_date($(this));
    new_order_post_type($(this));

  });

  function new_order_post_type(type){

    $('select[name=unit_of_measures_weight]').val('Standard').change();
    $('input[name=weight]').attr('max',31);
    $('input[name=ounches]').attr('max',70);
    $('input[name=pounds]').attr('max',70);
    $('.new-order').find('#weight_input').find('.tooltiptext').empty();
    $('.new-order').find('#weight_input').find('.tooltiptext').append('Weight must be between 0 and 31 kilograms.');
    $('.new-order').find('#pounds_input').find('.tooltiptext').empty();
    $('.new-order').find('#pounds_input').find('.tooltiptext').append('Total weight must be between 0 and 70 pounds, or 0 and 1120 ounces, or a combination thereof.');
    $('.new-order').find('#ounches_input').find('.tooltiptext').empty();
    $('.new-order').find('#ounches_input').find('.tooltiptext').append('Total weight must be between 0 and 70 pounds, or 0 and 1120 ounces, or a combination thereof.');


    if(type.val() === 'POSTCARD' || type.val() === 'ENVELOPE'){

      //       Hide Shape Input
      $('.new-order').find('#shape_input').addClass('hide');
      //       Hide Unit of Measure of Weight
      $('.new-order').find('#measures_input').addClass('hide');
      $('.new-order').find('#special_handling').addClass('hide');

      if(type.val() === 'POSTCARD'){
        $('.new-order').find('#postcard_size').removeClass('hide');
      }
      else{
        $('.new-order').find('#postcard_size').addClass('hide');
      }

      //       Hide Dimensions Input and making it not required
      $('.new-order').find('#girth_input').addClass('hide');
      $('.new-order').find('#girth_input').find('input[name=girth]').prop('required',false);

      $('.new-order').find('#height_input').addClass('hide');
      $('.new-order').find('#height_input').find('input[name=height]').prop('required',false);

      $('.new-order').find('#length_input').addClass('hide');
      $('.new-order').find('#length_input').find('input[name=length]').prop('required',false);

      $('.new-order').find('#width_input').addClass('hide');
      $('.new-order').find('#width_input').find('input[name=width]').prop('required',false);

      $('.new-order').find('#weight_input').addClass('hide');
      $('.new-order').find('#weight_input').find('input[name=weight]').prop('required',false);

      $('.new-order').find('#pounds_input').addClass('hide');
      $('.new-order').find('#pounds_input').find('input[name=pounds]').prop('required',false);

      $('.new-order').find('#ounches_input').addClass('hide');
      $('.new-order').find('#ounches_input').find('input[name=ounches]').prop('required',false);

    }

    else if(type.val() === 'LETTER' || type.val() === 'LARGE ENVELOPE'){
      //       Hide Shape Input
      $('.new-order').find('#shape_input').addClass('hide');
      //       Hide Unit of Measure of Weight
      if(type.val() === 'LETTER'){
        $('.new-order').find('#special_handling').removeClass('hide');
      }
      else{
        $('.new-order').find('#special_handling').addClass('hide');
      }


      $('.new-order').find('#postcard_size').addClass('hide');
      $('.new-order').find('#measures_input').removeClass('hide');
      //       Hide Dimensions Input and making it not required
      $('.new-order').find('#girth_input').addClass('hide');
      $('.new-order').find('#girth_input').find('input[name=girth]').prop('required',false);

      $('.new-order').find('#height_input').addClass('hide');
      $('.new-order').find('#height_input').find('input[name=height]').prop('required',false);

      $('.new-order').find('#length_input').addClass('hide');
      $('.new-order').find('#length_input').find('input[name=length]').prop('required',false);

      $('.new-order').find('#width_input').addClass('hide');
      $('.new-order').find('#width_input').find('input[name=width]').prop('required',false);

      $('.new-order').find('#weight_input').css('width','100%');
      $('.new-order').find('#weight_input').addClass('hide');
      $('.new-order').find('#weight_input').find('input[name=weight]').prop('required',false);
      $('.new-order').find('#pounds_input').removeClass('hide');
      $('.new-order').find('#pounds_input').find('input[name=pounds]').prop('required',true);

      $('.new-order').find('#ounches_input').removeClass('hide');
      $('.new-order').find('#ounches_input').find('input[name=ounches]').prop('required',false);
    }
    else {
      $('.new-order').find('#postcard_size').addClass('hide');
      if(type.val() === 'LARGE PACKAGE'){  

        $('.new-order').find('#special_handling').addClass('hide');
        //       Setting Limit on Length Input
        length_limit(12,'',type,'');
        //       Setting Limit on Height Input
        height_limit(12,'',type,'');
        //       Setting Limit on width Input
        width_limit(12,'',type,'');
        //         Setting Limmit on Girth Input
        girth_limit(12,'',type,'');

        $('.new-order').find('#shape_input').removeClass('hide');
        //       Hide Unit of Measure of Weight
        $('.new-order').find('#measures_input').removeClass('hide');
        $('.new-order').find('#height_input').removeClass('hide');
        $('.new-order').find('#height_input').find('input[name=height]').prop('required',true);

        $('.new-order').find('#length_input').removeClass('hide');
        $('.new-order').find('#length_input').find('input[name=length]').prop('required',true);

        $('.new-order').find('#width_input').removeClass('hide');
        $('.new-order').find('#width_input').find('input[name=width]').prop('required',true);
        if($('.new-order').find('#shape_input').find('select[name=shape]').val() === 'Rectangular'){
          $('.new-order').find('#girth_input').addClass('hide');
          $('.new-order').find('#girth_input').find('input[name=girth]').prop('required',false);
          $('.new-order').find('#width_input').css('width','100%');
          $('.new-order').find('#width_input').removeClass('hide');
          $('.new-order').find('#width_input').find('input[name=width]').prop('required',true);
        }
        else{

          $('.new-order').find('#girth_input').removeClass('hide');
          $('.new-order').find('#girth_input').find('input[name=girth]').prop('required',true);
          $('.new-order').find('#width_input').css('width','50%');
          $('.new-order').find('#width_input').removeClass('hide');
          $('.new-order').find('#width_input').find('input[name=width]').prop('required',true);

        }

      }
      else{
        $('.new-order').find('#special_handling').addClass('hide');
        //       Setting Limit on Length Input
        length_limit(0,12,type,'');
        //       Setting Limit on Height Input
        height_limit(0,12,type,'');
        //       Setting Limit on width Input
        width_limit(0,12,type,'');
        //         Setting Limmit on Girth Input
        girth_limit(0,12,type,'');
        $('.new-order').find('#shape_input').addClass('hide');
        //       Hide Unit of Measure of Weight
        $('.new-order').find('#measures_input').removeClass('hide');
        $('.new-order').find('#height_input').addClass('hide');
        $('.new-order').find('#height_input').find('input[name=height]').prop('required',false);

        $('.new-order').find('#length_input').addClass('hide');
        $('.new-order').find('#length_input').find('input[name=length]').prop('required',false);

        $('.new-order').find('#width_input').addClass('hide');
        $('.new-order').find('#width_input').find('input[name=width]').prop('required',false);

      }



      $('.new-order').find('#weight_input').addClass('hide');
      $('.new-order').find('#weight_input').find('input[name=weight]').prop('required',false);
      $('.new-order').find('#weight_input').css('width','100%');
      $('.new-order').find('#pounds_input').removeClass('hide');
      $('.new-order').find('#pounds_input').find('input[name=pounds]').prop('required',true);

      $('.new-order').find('#ounches_input').removeClass('hide');
      $('.new-order').find('#ounches_input').find('input[name=ounches]').prop('required',false);



    }

  }

  function length_limit(min,max,type,unit){
    if(unit === ''){
      unit = 'inches';
    }
    $('.new-order').find('#length_input').find('input[name=length]').attr('min',min);
    $('.new-order').find('#length_input').find('input[name=length]').attr('max',max);
    $('.new-order').find('#length_input').find('.tooltiptext').empty();
    if(type.val() === 'LARGE PACKAGE'){
      if(unit !== 'inches'){
        $('.new-order').find('#length_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 30cm, but the sum of all dimensions may not exceed 330cm. Packages with a dimensional sum larger than 274cm are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 274cm.');
      }
      else{
        $('.new-order').find('#length_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 12", but the sum of all dimensions may not exceed 130 cm. Packages with a dimensional sum larger than 108" are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 108".');

      }

    }
    else{
      $('.new-order').find('#length_input').find('.tooltiptext').append('Length should be in between '+min+' and '+max+' '+unit);
    }
  }

  function height_limit(min,max,type,unit){
    if(unit === ''){
      unit = 'inches';
    }
    $('.new-order').find('#height_input').find('input[name=height]').attr('min',min);
    $('.new-order').find('#height_input').find('input[name=height]').attr('max',max);
    $('.new-order').find('#height_input').find('.tooltiptext').empty();
    if(type.val() === 'LARGE PACKAGE'){
      if(unit !== 'inches'){
        $('.new-order').find('#height_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 30cm, but the sum of all dimensions may not exceed 330cm. Packages with a dimensional sum larger than 274cm are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 274cm.');
      }
      else{
        $('.new-order').find('#height_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 12", but the sum of all dimensions may not exceed 130 cm. Packages with a dimensional sum larger than 108" are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 108".');

      }
    }
    else{
      $('.new-order').find('#height_input').find('.tooltiptext').append('Height should be greater than '+min+' '+unit);
    }

  }

  function width_limit(min,max,type,unit){
    if(unit === ''){
      unit = 'inches';
    }
    $('.new-order').find('#width_input').find('input[name=width]').attr('min',min);
    $('.new-order').find('#width_input').find('input[name=width]').attr('max',max);
    $('.new-order').find('#width_input').find('.tooltiptext').empty();
    if(type.val() === 'LARGE PACKAGE'){
      if(unit !== 'inches'){
        $('.new-order').find('#width_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 30cm, but the sum of all dimensions may not exceed 330cm. Packages with a dimensional sum larger than 274cm are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 274cm.');
      }
      else{
        $('.new-order').find('#width_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 12", but the sum of all dimensions may not exceed 130 cm. Packages with a dimensional sum larger than 108" are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 108".');
      }

    }
    else{
      $('.new-order').find('#width_input').find('.tooltiptext').append('Width should be in between '+min+' and '+max+' '+unit);
    }

  }

  function girth_limit(min,max,type,unit){
    if(unit === ''){
      unit = 'inches';
    }
    $('.new-order').find('#girth_input').find('input[name=girth]').attr('min',min);
    $('.new-order').find('#girth_input').find('input[name=girth]').attr('max',max);
    $('.new-order').find('#girth_input').find('.tooltiptext').empty();
    if(type.val() === 'LARGE PACKAGE'){
      if(unit !== 'inches'){
        $('.new-order').find('#girth_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 30cm, but the sum of all dimensions may not exceed 330cm. Packages with a dimensional sum larger than 274cm are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 274cm.');
      }
      else{
        $('.new-order').find('#girth_input').find('.tooltiptext').append('A large package must have at least one dimension larger than 12", but the sum of all dimensions may not exceed 130 cm. Packages with a dimensional sum larger than 108" are subject to oversized surcharge. The maximum dimensional sum for shipping method USPS Retail Ground is 108".');
      }
    }
    else{
      $('.new-order').find('#girth_input').find('.tooltiptext').append('Girth should be greater than '+min+' '+unit);
    }
  }

  $('body').on('change','select[name=unit_of_measures_weight]',function(){
    measures($(this));
  });

  function measures($this){
    if($this.val() === 'Standard'){
      $('.new-order').find('#weight_input').addClass('hide');
      $('.new-order').find('#weight_input').find('input[name=weight]').prop('required',false);

      $('.new-order').find('#pounds_input').removeClass('hide');
      $('.new-order').find('#pounds_input').find('input[name=pounds]').prop('required',true);

      $('.new-order').find('#ounches_input').removeClass('hide');
      $('.new-order').find('#ounches_input').find('input[name=ounches]').prop('required',false);

      if($('#TypeSelect').val() === 'LARGE PACKAGE'){  
        //       Setting Limit on Length Input
        length_limit(12,'',$('#TypeSelect'),'');
        //       Setting Limit on Height Input
        height_limit(12,'',$('#TypeSelect'),'');
        //       Setting Limit on width Input
        width_limit(12,'',$('#TypeSelect'));
        //         Setting Limmit on Girth Input
        girth_limit(12,'',$('#TypeSelect'),'');

      }
      else{
        //       Setting Limit on Length Input
        length_limit(0,12,$('#TypeSelect'),'');
        //       Setting Limit on Height Input
        height_limit(0,12,$('#TypeSelect'),'');
        //       Setting Limit on width Input
        width_limit(0,12,$('#TypeSelect'),'');
        //         Setting Limmit on Girth Input
        girth_limit(0,12,$('#TypeSelect'),'');

      }


    }
    else{
      $('.new-order').find('#weight_input').removeClass('hide');
      $('.new-order').find('#weight_input').find('input[name=weight]').prop('required',true);

      $('.new-order').find('#pounds_input').addClass('hide');
      $('.new-order').find('#pounds_input').find('input[name=pounds]').prop('required',false);

      $('.new-order').find('#ounches_input').addClass('hide');
      $('.new-order').find('#ounches_input').find('input[name=ounches]').prop('required',false);
      if($('#TypeSelect').val() === 'LARGE PACKAGE'){  
        //       Setting Limit on Length Input
        length_limit(30.48,'',$('#TypeSelect'),'cm');
        //       Setting Limit on Height Input
        height_limit(30.48,'',$('#TypeSelect'),'cm');
        //       Setting Limit on width Input
        width_limit(30.48,'',$('#TypeSelect'),'cm');
        //         Setting Limmit on Girth Input
        girth_limit(30.48,'',$('#TypeSelect'),'cm');

      }
      else{
        //       Setting Limit on Length Input
        length_limit(0,30.48,$('#TypeSelect'),'cm');
        //       Setting Limit on Height Input
        height_limit(0,30.48,$('#TypeSelect'),'cm');
        //       Setting Limit on width Input
        width_limit(0,30.48,$('#TypeSelect'),'cm');
        //         Setting Limmit on Girth Input
        girth_limit(0,30.48,$('#TypeSelect'),'cm');

      }
    }
  }

  $('body').on('keyup','input[name=pounds]',function(){

    $('input[name=weight]').val($(this).val()*0.45359237);

  });

  $('body').on('keyup','input[name=weight]',function(){

    var val = $(this).val()/0.45359237;
    var str = val.toString().split('.');
    $('input[name=pounds]').val(str[0]); 
    $('input[name=ounches]').val('0.'+str[1]);

  });

  $('body').on('change','select[name="shape"]',function(){
    if($(this).val() === 'Rectangular'){
      $('.new-order').find('#girth_input').addClass('hide');
      $('.new-order').find('#girth_input').find('input[name=girth]').prop('required',false);
      $('.new-order').find('#width_input').css('width','100%');
      $('.new-order').find('#width_input').removeClass('hide');
      $('.new-order').find('#width_input').find('input[name=width]').prop('required',true);
    }
    else{

      $('.new-order').find('#girth_input').removeClass('hide');
      $('.new-order').find('#girth_input').find('input[name=girth]').prop('required',true);
      $('.new-order').find('#width_input').css('width','50%');
      $('.new-order').find('#width_input').removeClass('hide');
      $('.new-order').find('#width_input').find('input[name=width]').prop('required',true);
    }
  });

  $('body').on('click','#set_all_addresses_button',function(){

    if($('#Address').val() !== '---' && $('#Address').val() !== null){
      $.ajax({
        type:'GET',
        url: APP_URL+'/set_all_addresses',
        data:{

          address_id : $('#Address').val(),

        },
        success:function(data){
          location.reload();
        },

      });
    }
  });


  $('.new-addresses-page').ready(function(){
    if ($('body .new-addresses-page').length > 0) {
      let searchParams = new URLSearchParams(window.location.search);
      let param = searchParams.get('type');
      if(param){
        $('#Address-Type').val(param).change();
      }
    }
  });

  $('#cancel-order').click(function(){
    let searchParams = $(location).attr("href");
    var $this = $(this);
    var res = searchParams.split("/");

    $.ajax({
      type:'GET',
      url: APP_URL+'/cancel/order',
      data:{
        order_token : res[5],
      },
      success:function(data){
        if(data.status === 'success'){
          $this.next().addClass('success');
          $this.next().text(data.message);
          $this.next().show();
          location.reload();
        }
        if(data.status == 'permission'){
          if (confirm("Are you sure you want to cancel your shipment?")) {
            $.ajax({
              type:'POST',
              url: APP_URL+'/cancel/order/process',
              data:{
                order_token : res[5],
                permission : data.message_status,

              },
              success:function(data){
                if(data.status === 'success'){
                  $this.next().addClass('success');
                  $this.next().text(data.message);
                  if(data.response === 6){
                    $this.next().append('<br><button style="margin-top:5px" onclick="location.reload()" class="Same-button"> Ok</button>')

                  }
                  else{
                    $this.next().append('<br><button style="margin-top:5px" onclick="location.reload()" class="Same-button"> Ok, Show my Options </button>')

                  }
                  $this.next().show();
                  //                     location.reload();
                }
                else{
                  $this.next().addClass('error');
                  $this.next().text(data.message);
                  $this.next().show();
                }
              },
            });
          }

        }
        else{
          $this.next().addClass('error');
          $this.next().text(data.message);
          $this.next().show();
        }

      },

    });

    return false;

  });

  $('body').on('click','#customer_delete_account',function(){
    if (confirm("Are you sure you want to delete the account?")) {
      $.ajax({
        type:'GET',
        url: APP_URL+'/delete/account/confirmation',
        data:{
          customer : $(this).data('id'),
        },
        success:function(data){
          window.location.href = 'https://postdelay.myshopify.com/account/logout';
        },
      });
    }
    return false;
  });

  //   AddToCartWithShipping(31106430959697);

  function AddToCartWithShipping(product){
    $('#shopify_product_id').val(product);
    $.ajax({
      type: 'GET',
      url: '/cart/clear.js',
      dataType: 'json',
      success: function() { 
        $.ajax({
          type: 'POST',
          url: '/cart/add.js',
          data: 'quantity=1&id='+product,
          dataType: 'json',
          success: function(cart) { 
            console.log(cart)           
            CalculateShippingAppend();
          }
        });

      },
      error: function(XMLHttpRequest, textStatus) {

      }
    });
  }

  //   function CalculateShippingAppend(){
  //     $.ajax({
  //       type: 'POST',
  //       url: '/cart/shipping_rates.json?shipping_address%5Bzip%5D=10001&shipping_address%5Bcountry%5D=United States&shipping_address%5Bprovince%5D=New York',
  //       success: function(s) { 
  //         $('#shipping_method_select').empty();
  //         $('#shipping_method_select').prop('required', true);
  //         $('#shipping_method_select').append('<option value="">--Select--</option>')
  //         if(s.shipping_rates.length >= 0){
  //           $.each(s.shipping_rates, function(i, item) {
  //             var $type = $('#TypeSelect').val();
  //             var price = parseFloat(item.price);
  //             var $commission_type = $('#TypeSelect option[value="'+$type+'"]').attr('data-commission');
  //             var $commission_value = parseFloat($('#TypeSelect option[value="'+$type+'"]').attr('data-commission-type'));
  //             if($commission_type == 'fixed'){
  //               var f_price = price + $commission_value;
  //             }else{
  //               var f_price = price + (price * $commission_value/100)
  //               }
  //             f_price = f_price.toFixed(2);
  //             var full_name = item.presentment_name+' ($'+f_price+')';
  //             var full_name2 = item.presentment_name+' ($'+item.price+')';
  //             $('#shipping_method_select').append('<option value="'+item.presentment_name+'" data-price="'+f_price+'">'+full_name+'</option>');

  //             $('#shipping_method_selects2').append('<option value="'+item.presentment_name+'" data-price="'+item.price+'">'+full_name2+'</option>');

  //           });
  //         }
  //         else {

  //         }
  //         $('.shipping_calculations').show();
  //         $('.place_order_form').attr('id','place_order_form');
  //         $('.place_order_form').attr('action','/place/order');
  //         $('.page-width-2').removeClass('loading');
  //         $('.qoute_button').val('REFRESH QUOTE');
  //         $('.qoute_button').removeClass('not-modified');
  //         //         $('.quote_button').attr('type','button');
  //         //         $('.final_submit_button').attr('type','submit');
  //         //         $('.shipment_details').addClass('disabled');
  //       }
  //     }); 
  //   }


  function CalculateShippingAppend(){
    var form = $('#get_shipping_rates');
    $.ajax({
      type: 'GET',
      url: APP_URL+'/test/usps',
      data:form.serialize(),
      success: function(s) { 
        if(s.error === null){
          $('#shipping_method_select').empty();
          $('#shipping_method_selects2').empty();
          $('#shipping_method_select').prop('required', true);
          $('#shipping_method_select').append('<option value="">--Select--</option>')
          console.log(s.services.length);
          if(s.services.length >= 1){
            $.each(s.services, function(i, item) {
              console.log(item);

              if(s.status === 'domestic'){

                set_rates(item.Rate,item.MailService);

              }
              else{

                set_rates(item.Postage,item.SvcDescription+' '+item.SvcCommitments);
              }


            });

          }
          else if(s.services.MailService !== null && s.status === 'domestic') {
            set_rates(s.services.Rate,s.services.MailService);

          }
          else if(s.services.MailService !== null && s.status === 'international'){
            set_rates(s.services.Postage,s.services.SvcDescription+' '+s.services.SvcCommitments);
          }
          else{

          }
          //           set_commision();
          $('#shipping_method_select').find('option').each(function(){
            $(this).val($(this).text());
          });
          $('[name="new_shipping_price"]').next().empty();
          $('.shipping_calculations').find('.order-invoice-price').find('input[name=new_shipping_price]').next().text('Select From Dropdown');
          $('.shipping_calculations').find('input[name=new_total_fee]').next().text($('input[name=new_postdelay_fee]').next().text());
          $('.shipping_calculations').show();
          $('.place_order_form').attr('id','place_order_form');
          $('.place_order_form').attr('action','/place/order');
          $('.page-width-2').removeClass('loading');
          $('.qoute_button').val('REFRESH QUOTE');
          $('.qoute_button').removeClass('not-modified');


        }
        else{
          $('.page-width-2').removeClass('loading');
          alert(s.error);
        }
      }
    }); 
  }

  function set_rates(rate,name){

    if(rate != '0.00'){

      var $type = $('#TypeSelect').val();
      var $commission_type = $('#TypeSelect option[value="'+$type+'"]').attr('data-commission');
      var $commission_value = parseFloat($('#TypeSelect option[value="'+$type+'"]').attr('data-commission-type'));

      console.log('the original rate: '+rate);
      console.log('$commission_type: '+ $commission_type);
      console.log('commission_value: '+ $commission_value);

      $('body').find('#tempo').append(name);
      name =$('body').find('#tempo').text();
      $('body').find('#tempo').empty();

      var price = parseFloat(rate);


//       if($commission_type == 'fixed'){
//         var f_price = price + $commission_value;
//       } else {
//        var f_price = price + (price * $commission_value/100);
//       }

      price = price.toFixed(2);

      var full_name = name+' ($'+price+')';
      var full_name2 = name+' ($'+price+')';

      console.log('rate: '+ rate);
      console.log('name: '+ name);


      console.log('full_name: '+ full_name);
      $('#shipping_method_select').append('<option value="'+name+'"  data-price="'+price+'">'+full_name+'</option>');
      $('#shipping_method_selects2').append('<option value="'+name+'"  data-price="'+price+'">'+full_name2+'</option>');
      $('#shipping_method_selects2').parents('.custom_fields_half').hide();

    }

  }

  function set_commision(selected){
    var $type = $('#TypeSelect').val();
    var post_delay_fee = parseFloat($('input[name=new_postdelay_fee]').attr('data-price'));
     var usps_fee = parseFloat(selected.find('option[value="'+selected.val()+'"]').attr('data-price'));
    console.log(post_delay_fee,usps_fee);

    var $commission_type = $('#TypeSelect option[value="'+$type+'"]').attr('data-commission');
    var $commission_value = parseFloat($('#TypeSelect option[value="'+$type+'"]').attr('data-commission-type'));

    console.log('$commission_type: '+ $commission_type);
    console.log('commission_value: '+ $commission_value);


    if($commission_type == 'fixed'){
      var f_price = post_delay_fee  + $commission_value;
    } else {
      var f_price = post_delay_fee + (usps_fee * $commission_value/100);
    }

    $('input[name=new_postdelay_fee]').val(f_price);
    $('input[name=new_postdelay_fee]').next().text('$'+f_price.toFixed(2));

  }

  function address_status(status){
    if(status){
      $('.address_dropdown').show();
      $('.address_status').hide();
      $('.address_status .status_wrapper').text('');
    }else{
      $('.address_dropdown').hide();
      $('.address_status').show();
      $('.address_status .status_wrapper').text('No address found.').show();
      $('.address_dropdown select').empty();
    }
    $('.Form-content-detail').hide();
  }

  function calculateTotalAmount(){
    var total = 0;
    $('.caclulated_amount').each(function(){
      total = total + parseFloat($(this).val());
      console.log($(this).val(), total);
    });

    $('[name="new_total_fee"]').val(total);
    $('[name="new_total_fee"]').next().text('$'+total.toFixed(2));
  }

  function DatresCompare(d1,d2){
    var date1 = new Date(d1); 
    var date2 = new Date(d2); 
    var Difference_In_Time = date2.getTime() - date1.getTime(); 
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24); 
    console.log(Difference_In_Days); 
  }


  $('body').on('change', '#shipping_method_select', function(){
    var price = parseFloat($(this).find('option[value="'+$(this).val()+'"]').attr('data-price'));
    $('[name="new_shipping_price"]').val(price);
    $('[name="new_shipping_price"]').next().text('$'+price.toFixed(2));
    set_commision($(this));
    calculateTotalAmount();

  });

});


function parseHtmlEnteties(str) {
  return str.replace(/&#([0-9]{1,3});/gi, function(match, numStr) {
    var num = parseInt(numStr, 10); // read num as normal number
    return String.fromCharCode(num);
  });
}


function status_message($this, text, type){

  $this.find('.status_wrapper').html(text);
  $this.find('.status_wrapper').show();
  if(type == 'success'){
    $this.find('.status_wrapper').addClass('success');
    $this.find('.status_wrapper').addClass('error');
  }else{
    $this.find('.status_wrapper').addClass('error');
    $this.find('.status_wrapper').addClass('success');
  }
}
function deleteAccount(APP_URL, id){
  $.ajax({
    type:'GET',
    url: APP_URL+'/delete/account',
    data:{
      customer : id,
    },
    success:function(data){
      $('.Form-wraper').removeClass('loading');
      $('.Form-content-detail_custom').text('Account Deleted Successfully.')
    },
    error: function(){
      $('.Form-wraper').removeClass('loading');
      $('.Form-content-detail_custom').text('The Account associated with this id not found or already deleted.')
    }
  });
}


$('body').on('focus','.autocomplete',function(){
  var id = $(this).attr('id');
  initAutocomplete(id);

});

$('body').on('change','.modify',function(){
  $('#modification').val('1');
  $('.place_order_form').attr('id','get_shipping_rates');
  $('.place_order_form').attr('action','/get_shipping_rates');
  $('#shipping_method_select').prop('required',false);
  $('.shipping_calculations').hide();
  if(!$('.qoute_button').hasClass('not-modified')){
    $('.qoute_button').val('Refresh Quote');
  }

});

$('body').on('change','input[name=response]',function(){
  if($(this).val() === '9'){
    $('.status_wrapper').empty();
    $('.status_wrapper').addClass('success');
    $('.status_wrapper').removeClass('error');
    $('.status_wrapper').show();
    $('.status_wrapper').append('Your order has been cancelled. Within one business day, we will calculate the cost to return your mailing. If the amount to return the item to you is less than you originally paid, the difference in cost will be refunded to your original method of payment. If the amount to return the item to you is more than you originally paid, you will receive a link to pay for the difference in cost. ');
  }
  else if($(this).val() === '8'){
    $('.status_wrapper').empty();
    $('.status_wrapper').addClass('success');
    $('.status_wrapper').removeClass('error');
    $('.status_wrapper').show();
    $('.status_wrapper').append('Your order has been cancelled. The shipping cost for your order has been refunded to your original method of payment.');
  }
  else{
    $('.status_wrapper').addClass('success');
    $('.status_wrapper').removeClass('error');
    $('.status_wrapper').hide();
    $('.status_wrapper').empty();
  }


});



var placeSearch, autocomplete;
var componentForm = {
  street_number: 'short_name',
  route: 'long_name',
  locality: 'long_name',
  administrative_area_level_1: 'long_name',
  country: 'long_name',
  postal_code: 'short_name',
  sublocality_level_1 : 'long_name'
};



var current;

function initAutocomplete(id) {

  if($('#Address-Type').val() === 'Billing' || $('#Address-Type').val()==='Sender'){

    var countryRestrict = null;
  }
  else if($('#Address-Type').val() === 'Recipients')
  {
    var countryRestrict = {'country': ['us', 'ca', 'mx']};
  }
  else{
    var countryRestrict = null;
  }
  var new_id = '#'+id; 
  var new_order = $(new_id).prev().val();

  if(new_order === 'billing' || new_order === 'sender'){
    var countryRestrict = null;
  }

  if(new_order === 'r'){
    var countryRestrict = {'country': ['us', 'ca', 'mx']};
  }

  var input =  document.getElementById(id);

  //   for (i = 0; i < input.length; i++) {

  current = input;
  autocomplete = new google.maps.places.Autocomplete(
    input, {
      //         types: ['geocode'],
      language: ['en'],
      componentRestrictions: countryRestrict
    });
  autocomplete.setFields(['address_component']);
  autocomplete.addListener('place_changed', fillInAddress);  

  //   }

}


function fillInAddress() {

  var place = autocomplete.getPlace();
  console.log(place);
  // Empty Existing data
  $(current).val('');
  $(current).parents('.full_width_iput').next().find('input').first().val('');
  $(current).next().val('');
  $(current).next().next().val('');
  $(current).parents('.full_width_iput').next().find('#administrative_area_level_1').val('');
  $(current).parents('.full_width_iput').next().find('input').last().val('');

  for (var i = 0; i < place.address_components.length; i++) 
  {
    var addressType = place.address_components[i].types[0];
    console.log(addressType);
    if (componentForm[addressType]) {
      var val = place.address_components[i][componentForm[addressType]];
      if(addressType === 'street_number'){
        $(current).val(val);
        $(current).next().val(val);
      }    
      if(addressType === 'route'){
        var st = $(current).val();
        val = st +' '+val;
        //         $(current).next().next().val(val);
        $(current).val(val);
        $(current).next().val(val);
      }

      if(addressType === 'sublocality_level_1'){
        $(current).parents('.full_width_iput').next().find('input').first().val(val);
      }
      if(addressType === 'locality'){
        $(current).parents('.full_width_iput').next().find('input').first().val(val);
      }

      if(addressType === 'administrative_area_level_1'){
        $(current).parents('.full_width_iput').next().find('#administrative_area_level_1').val(val);
      }
      if(addressType === 'postal_code'){
        $(current).parents('.full_width_iput').next().find('input').last().val(val);
      }
      if(addressType === 'country'){
        //         if($(current).parents('.full_width_iput').prev().prev().find('select').val()){

        //         }else {
        $(current).parents('.full_width_iput').prev().prev().find('select').val(val).change();
        //         }
      }
    }
  }
}



